
-- Role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

-- user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Security definer role check
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert roles"
  ON public.user_roles FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete roles"
  ON public.user_roles FOR DELETE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- knowledge_base table
CREATE TABLE public.knowledge_base (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  keywords TEXT NOT NULL,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.knowledge_base ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read knowledge base"
  ON public.knowledge_base FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert knowledge base"
  ON public.knowledge_base FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update knowledge base"
  ON public.knowledge_base FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete knowledge base"
  ON public.knowledge_base FOR DELETE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_knowledge_base_updated_at
  BEFORE UPDATE ON public.knowledge_base
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Index for keyword search
CREATE INDEX idx_knowledge_base_keywords ON public.knowledge_base USING gin (to_tsvector('english', keywords || ' ' || question));

-- Seed 22 common medical Q&As
INSERT INTO public.knowledge_base (keywords, question, answer) VALUES
('fever,temperature,pyrexia', 'What is fever?', 'Fever is a temporary increase in body temperature, often due to an illness. A normal body temperature is around 37°C (98.6°F). A reading above 38°C (100.4°F) is generally considered a fever. Rest, fluids, and over-the-counter remedies usually help.'),
('cold,cough,runny nose,sneeze', 'What is the common cold?', 'The common cold is a viral infection of the nose and throat. Symptoms include runny nose, sore throat, cough, congestion, and mild fever. Most colds resolve on their own within 7–10 days with rest and fluids.'),
('headache,head pain,migraine', 'What causes a headache?', 'Headaches can be caused by stress, dehydration, lack of sleep, eye strain, or underlying conditions like migraine. Drink water, rest in a dark room, and consider mild pain relief. Seek medical help if severe or sudden.'),
('blood pressure,bp,hypertension', 'What is high blood pressure?', 'High blood pressure (hypertension) means the force of blood against artery walls is consistently too high. Normal BP is around 120/80 mmHg. Long-term hypertension increases risk of heart disease and stroke. Lifestyle changes and regular monitoring help.'),
('diabetes,sugar,glucose', 'What is diabetes?', 'Diabetes is a chronic condition where blood sugar levels are too high. Type 1 is autoimmune; Type 2 is linked to lifestyle and genetics. Symptoms include thirst, frequent urination, and fatigue. Diet, exercise, and medication help manage it.'),
('asthma,wheezing,breathing', 'What is asthma?', 'Asthma is a chronic condition where airways narrow and swell, causing wheezing, shortness of breath, and coughing. Triggers include allergens, exercise, and cold air. Inhalers and avoiding triggers are common management strategies.'),
('flu,influenza,body ache', 'What is the flu?', 'Influenza (flu) is a contagious respiratory illness caused by influenza viruses. Symptoms include fever, body aches, fatigue, cough, and sore throat. Annual vaccination is the best prevention.'),
('covid,coronavirus,covid19', 'What is COVID-19?', 'COVID-19 is a respiratory illness caused by the SARS-CoV-2 virus. Symptoms include fever, cough, fatigue, and loss of taste or smell. Vaccination, masks, and hand hygiene help reduce spread.'),
('diarrhea,loose motion,stomach', 'What causes diarrhea?', 'Diarrhea is loose, watery stools, often caused by viral or bacterial infections, food poisoning, or stress. Stay hydrated with water and oral rehydration solutions. See a doctor if it lasts more than 2 days.'),
('vomiting,nausea,puking', 'What causes vomiting?', 'Vomiting can be caused by infections, food poisoning, motion sickness, or other conditions. Sip clear fluids slowly to stay hydrated. Seek medical care if vomiting persists or contains blood.'),
('constipation,bowel,stool', 'What is constipation?', 'Constipation means infrequent or hard-to-pass stools. Causes include low fiber intake, dehydration, and inactivity. Eat fiber-rich foods, drink water, and exercise regularly to help.'),
('allergy,allergic,rash,itch', 'What is an allergy?', 'An allergy is the immune system''s reaction to a normally harmless substance like pollen, dust, or food. Symptoms include sneezing, itching, rash, or swelling. Antihistamines and avoiding triggers help.'),
('anemia,iron,fatigue,weakness', 'What is anemia?', 'Anemia occurs when blood lacks enough healthy red blood cells, often due to iron deficiency. Symptoms include fatigue, weakness, and pale skin. Iron-rich foods and supplements can help.'),
('obesity,weight,bmi', 'What is obesity?', 'Obesity is excess body fat that increases risk of health problems like diabetes and heart disease. BMI over 30 is generally classified as obese. Balanced diet and regular exercise are key to management.'),
('cholesterol,ldl,hdl', 'What is cholesterol?', 'Cholesterol is a waxy substance in your blood. LDL is "bad" cholesterol; HDL is "good." High LDL increases heart disease risk. Healthy diet, exercise, and sometimes medication help control levels.'),
('depression,mood,sad', 'What is depression?', 'Depression is a mental health condition causing persistent sadness, loss of interest, and difficulty functioning. It is treatable with therapy, medication, and lifestyle support. Speak to a healthcare professional.'),
('anxiety,worry,panic', 'What is anxiety?', 'Anxiety is excessive worry or fear that interferes with daily life. Symptoms include restlessness, rapid heartbeat, and trouble sleeping. Therapy, relaxation techniques, and medication can help.'),
('insomnia,sleep,sleepless', 'What is insomnia?', 'Insomnia is difficulty falling or staying asleep. Causes include stress, caffeine, screen use, and medical conditions. Maintain a regular sleep schedule, limit screens before bed, and reduce caffeine.'),
('dehydration,thirst,water', 'What is dehydration?', 'Dehydration occurs when your body loses more fluids than it takes in. Signs include thirst, dry mouth, dark urine, and fatigue. Drink water regularly, especially in heat or during illness.'),
('uti,urine,burning urination', 'What is a UTI?', 'A urinary tract infection (UTI) is an infection in any part of the urinary system. Symptoms include burning during urination, frequent urge to urinate, and lower abdominal pain. Drink water and consult a doctor for antibiotics if needed.'),
('back pain,backache,spine', 'What causes back pain?', 'Back pain often results from poor posture, muscle strain, or lifting heavy objects. Most cases improve with rest, gentle stretching, and over-the-counter pain relief. See a doctor if pain is severe or persistent.'),
('skin rash,itching,eczema', 'What causes skin rashes?', 'Skin rashes can be caused by allergies, infections, heat, or conditions like eczema. Keep skin clean and moisturized. Consult a doctor if the rash spreads, blisters, or causes significant discomfort.');
