import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  attachments?: { type: string; name: string; url?: string }[];
  timestamp: Date;
}

export type ChatMode = "default" | "thinking" | "deep_search" | "study" | "quiz";

const NO_MATCH_REPLY = "Sorry, no data found.";
const DISCLAIMER = "\n\n---\n*This is a database-driven response (no AI). For educational purposes only — not a substitute for professional medical advice.*";

/** Tokenize input into lowercase keywords (drops short stop words). */
const tokenize = (text: string): string[] => {
  const stop = new Set(["a","an","the","is","of","to","in","on","for","and","or","i","my","me","do","you","what","whats","how","why","when","where","can","does","with","at","be","it","this","that","have","has","are","am","was","were"]);
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2 && !stop.has(t));
};

export const useChat = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentMode, setCurrentMode] = useState<ChatMode>("default");

  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  const loadMessages = useCallback(async (conversationId: string) => {
    try {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("conversation_id", conversationId)
        .order("created_at", { ascending: true });

      if (error) throw error;

      const loaded: Message[] = (data || []).map((m) => ({
        id: m.id,
        role: m.role as "user" | "assistant",
        content: m.content,
        attachments: m.attachments as Message["attachments"],
        timestamp: new Date(m.created_at),
      }));

      setMessages(loaded);
    } catch (error) {
      console.error("Error loading messages:", error);
      toast.error("Failed to load messages");
    }
  }, []);

  const saveMessage = useCallback(async (
    conversationId: string,
    role: "user" | "assistant",
    content: string,
    attachments?: Message["attachments"]
  ) => {
    try {
      await supabase.from("messages").insert({
        conversation_id: conversationId,
        role,
        content,
        attachments: (attachments as any) || [],
      });
    } catch (error) {
      console.error("Error saving message:", error);
    }
  }, []);

  const sendMessage = useCallback(async (
    content: string,
    conversationId: string | null,
    attachments?: { type: string; name: string; url?: string }[]
  ) => {
    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content,
      attachments,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    if (conversationId) {
      saveMessage(conversationId, "user", content, attachments);
    }

    try {
      // ── PURE DATABASE LOOKUP — NO AI ──────────────────────────────
      const tokens = tokenize(content);
      console.log("[DB-only mode] Searching knowledge_base. Tokens:", tokens);

      let bestAnswer: string | null = null;
      let bestQuestion: string | null = null;

      if (tokens.length > 0) {
        // Build OR filter across keywords + question for each token
        const filter = tokens
          .flatMap((t) => [`keywords.ilike.%${t}%`, `question.ilike.%${t}%`])
          .join(",");

        const { data, error } = await supabase
          .from("knowledge_base")
          .select("question,answer,keywords")
          .or(filter)
          .limit(20);

        if (error) {
          console.error("[DB-only mode] Lookup error:", error);
        } else if (data && data.length > 0) {
          // Score by number of token matches in keywords+question
          const scored = data.map((row) => {
            const hay = `${row.keywords} ${row.question}`.toLowerCase();
            const score = tokens.reduce((n, t) => (hay.includes(t) ? n + 1 : n), 0);
            return { ...row, score };
          });
          scored.sort((a, b) => b.score - a.score);
          bestAnswer = scored[0].answer;
          bestQuestion = scored[0].question;
          console.log("[DB-only mode] Match found:", bestQuestion, "score:", scored[0].score);
        } else {
          console.log("[DB-only mode] No matches in knowledge_base.");
        }
      }

      const assistantContent = bestAnswer
        ? `**${bestQuestion}**\n\n${bestAnswer}${DISCLAIMER}`
        : `${NO_MATCH_REPLY}${DISCLAIMER}`;

      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "assistant" as const,
          content: assistantContent,
          timestamp: new Date(),
        },
      ]);

      if (conversationId) {
        saveMessage(conversationId, "assistant", assistantContent);
      }
    } catch (error) {
      console.error("[DB-only mode] Chat error:", error);
      toast.error("Failed to look up answer. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [saveMessage]);

  return {
    messages,
    setMessages,
    isLoading,
    sendMessage,
    clearMessages,
    loadMessages,
    currentMode,
    setCurrentMode,
  };
};
