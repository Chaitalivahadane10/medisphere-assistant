import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Pencil, Trash2, ArrowLeft, Database } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useUserRole } from "@/hooks/useUserRole";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

interface KbEntry {
  id: string;
  keywords: string;
  question: string;
  answer: string;
  updated_at: string;
}

const empty = { id: "", keywords: "", question: "", answer: "", updated_at: "" };

const Admin: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, loading: roleLoading } = useUserRole();
  const [entries, setEntries] = useState<KbEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<KbEntry | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) navigate("/auth");
  }, [user, authLoading, navigate]);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("knowledge_base")
      .select("*")
      .order("updated_at", { ascending: false });
    if (error) {
      toast.error("Failed to load knowledge base");
      console.error(error);
    } else {
      setEntries(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (isAdmin) load();
  }, [isAdmin]);

  const handleSave = async () => {
    if (!editing) return;
    const { keywords, question, answer } = editing;
    if (!keywords.trim() || !question.trim() || !answer.trim()) {
      toast.error("All fields are required");
      return;
    }
    if (editing.id) {
      const { error } = await supabase
        .from("knowledge_base")
        .update({ keywords, question, answer })
        .eq("id", editing.id);
      if (error) return toast.error("Update failed: " + error.message);
      toast.success("Entry updated");
    } else {
      const { error } = await supabase
        .from("knowledge_base")
        .insert({ keywords, question, answer });
      if (error) return toast.error("Create failed: " + error.message);
      toast.success("Entry created");
    }
    setEditing(null);
    load();
  };

  const handleDelete = async () => {
    if (!deletingId) return;
    const { error } = await supabase.from("knowledge_base").delete().eq("id", deletingId);
    if (error) toast.error("Delete failed: " + error.message);
    else toast.success("Entry deleted");
    setDeletingId(null);
    load();
  };

  if (authLoading || roleLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-10 h-10 border-4 border-accent border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 bg-background p-6">
        <Database className="w-12 h-12 text-muted-foreground" />
        <h1 className="text-2xl font-bold">Admin access required</h1>
        <p className="text-muted-foreground text-center max-w-md">
          You need the <code className="px-1.5 py-0.5 bg-muted rounded">admin</code> role to manage the knowledge base.
        </p>
        <Button onClick={() => navigate("/")}>Back to chat</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold flex items-center gap-2">
                <Database className="w-5 h-5 text-primary" />
                Knowledge Base Admin
              </h1>
              <p className="text-xs text-muted-foreground">
                Database-only chatbot — no AI. {entries.length} entries.
              </p>
            </div>
          </div>
          <Button onClick={() => setEditing({ ...empty })}>
            <Plus className="w-4 h-4 mr-2" /> Add entry
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6">
        {loading ? (
          <p className="text-muted-foreground">Loading…</p>
        ) : entries.length === 0 ? (
          <p className="text-muted-foreground">No entries yet. Click <strong>Add entry</strong>.</p>
        ) : (
          <div className="space-y-3">
            {entries.map((e) => (
              <div
                key={e.id}
                className="border rounded-lg p-4 bg-card hover:border-primary/40 transition-colors"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold">{e.question}</h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{e.answer}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {e.keywords.split(",").map((k, i) => (
                        <span
                          key={i}
                          className="text-xs px-2 py-0.5 bg-muted rounded-full text-muted-foreground"
                        >
                          {k.trim()}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button variant="ghost" size="icon" onClick={() => setEditing(e)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeletingId(e.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Edit/Create dialog */}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing?.id ? "Edit entry" : "New entry"}</DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="kw">Keywords (comma-separated)</Label>
                <Input
                  id="kw"
                  value={editing.keywords}
                  onChange={(e) => setEditing({ ...editing, keywords: e.target.value })}
                  placeholder="fever, temperature, pyrexia"
                />
              </div>
              <div>
                <Label htmlFor="q">Question</Label>
                <Input
                  id="q"
                  value={editing.question}
                  onChange={(e) => setEditing({ ...editing, question: e.target.value })}
                  placeholder="What is fever?"
                />
              </div>
              <div>
                <Label htmlFor="a">Answer</Label>
                <Textarea
                  id="a"
                  rows={6}
                  value={editing.answer}
                  onChange={(e) => setEditing({ ...editing, answer: e.target.value })}
                  placeholder="Fever is a temporary increase in body temperature…"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deletingId} onOpenChange={(o) => !o && setDeletingId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this entry?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove the entry from the knowledge base. The chat will no
              longer be able to answer related questions.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Admin;
