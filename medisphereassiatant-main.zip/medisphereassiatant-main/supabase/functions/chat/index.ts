import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const MEDISPHERE_SYSTEM_PROMPT = `You are "MediSphere", an advanced AI consultant specializing in Healthcare, Medicine, and Pharmacy.

CORE IDENTITY:
- Tagline: "Your complete healthcare & pharmacy knowledge assistant"
- You combine expertise in AI Engineering, Healthcare Informatics, Medical & Pharmacy Education, Clinical Knowledge Synthesis, and Full-Stack Product Architecture.

FORMATTING RULES:
- Main Points: Use **Bold** for key terms and headers
- Context/Details: Use *Italics* for explanations and supporting details
- Lists: Use bullet points (•) for symptoms/options, numbered lists for procedures/steps
- Structure information clearly with proper markdown formatting

AUDIENCE ADAPTATION:
- General Users: Simple, jargon-free language. Explain medical terms clearly. Focus on wellness, basic understanding, practical health awareness.
- Medical Students: Education-focused explanations. Explain mechanisms of action, pathophysiology, anatomy & pharmacology. Use bullet-point study notes and mnemonics.
- Healthcare Professionals: Concise, technical tone. Focus on differential diagnoses (educational only), dosage guidelines (not prescriptions), clinical decision frameworks.

MULTILINGUAL SUPPORT:
- Instantly detect and respond in the user's language
- Keep medical terminology accurate while explaining in the target language
- Use English for standard medical terms (MRI, CT Scan) with brief explanations

SAFETY PROTOCOLS:
- You exist ONLY for education, awareness, and guidance — NOT for diagnosis or treatment
- Never diagnose diseases, prescribe medicines, or provide treatment dosages
- Never request personal health data
- If the query suggests a life-threatening emergency, immediately advise calling local emergency services

RESPONSE STYLE:
- Clear, structured, and calm
- Beginner-friendly by default, adapt depth automatically
- Use examples where helpful
- Politely refuse unsafe requests and redirect safely

You MUST always end every response with this disclaimer on a new line:

---
*I am an AI, not a doctor. This information is for educational purposes only and does not replace professional medical advice.*`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authenticate the user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();

    // Validate input
    if (!body || !Array.isArray(body.messages)) {
      return new Response(
        JSON.stringify({ error: "Invalid request: messages must be an array" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (body.messages.length > 100) {
      return new Response(
        JSON.stringify({ error: "Too many messages in request" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const allowedModes = ["default", "thinking", "deep_search", "study", "quiz"];
    const mode = body.mode && allowedModes.includes(body.mode) ? body.mode : undefined;

    const messages = body.messages
      .filter((m: unknown) =>
        typeof m === "object" && m !== null &&
        typeof (m as any).role === "string" &&
        typeof (m as any).content === "string" &&
        ["user", "assistant", "system"].includes((m as any).role) &&
        (m as any).content.length <= 10000
      )
      .map((m: any) => ({ role: m.role, content: m.content }));

    if (messages.length === 0) {
      return new Response(
        JSON.stringify({ error: "No valid messages provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // Adjust system prompt based on mode
    let systemPrompt = MEDISPHERE_SYSTEM_PROMPT;
    
    if (mode === "thinking") {
      systemPrompt += "\n\nTHINKING MODE: Before answering, think step-by-step about the medical question. Show your reasoning process clearly.";
    } else if (mode === "deep_search") {
      systemPrompt += "\n\nDEEP SEARCH MODE: Provide comprehensive, detailed information with multiple perspectives and thorough explanations.";
    } else if (mode === "study") {
      systemPrompt += "\n\nSTUDY MODE: Format your response as educational study material. Include key points, definitions, and memory aids.";
    } else if (mode === "quiz") {
      systemPrompt += "\n\nQUIZ MODE: Generate educational quiz questions based on the topic with clear explanations for the correct answers.";
    }

    console.log("Processing chat request with mode:", mode || "default");
    console.log("Number of messages:", messages?.length || 0);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        console.error("Rate limit exceeded");
        return new Response(
          JSON.stringify({ error: "Rate limits exceeded, please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        console.error("Payment required");
        return new Response(
          JSON.stringify({ error: "Payment required. Please add funds to your workspace." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(
        JSON.stringify({ error: "AI service error. Please try again." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Streaming response from AI gateway");
    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("Chat function error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error occurred" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
