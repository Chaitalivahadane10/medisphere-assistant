import React, { useState, useRef, KeyboardEvent, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send,
  Mic,
  MicOff,
  Camera,
  Image,
  Paperclip,
  X,
  Brain,
  Search,
  GraduationCap,
  FileQuestion,
  Globe,
  ShoppingCart,
  MoreHorizontal,
  Languages,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { ChatMode } from "@/hooks/useChat";
import { useSpeechRecognition, stopSpeaking } from "@/hooks/useSpeech";

interface ChatInputProps {
  onSendMessage: (content: string, attachments?: { type: string; name: string }[]) => void;
  isLoading: boolean;
  currentMode: ChatMode;
  onModeChange: (mode: ChatMode) => void;
}

const modeConfig: Record<ChatMode, { icon: React.ReactNode; label: string; color: string }> = {
  default: { icon: null, label: "Default", color: "" },
  thinking: { icon: <Brain className="w-4 h-4" />, label: "Thinking", color: "text-purple-500" },
  deep_search: { icon: <Search className="w-4 h-4" />, label: "Deep Search", color: "text-blue-500" },
  study: { icon: <GraduationCap className="w-4 h-4" />, label: "Study & Learn", color: "text-green-500" },
  quiz: { icon: <FileQuestion className="w-4 h-4" />, label: "Quiz Mode", color: "text-orange-500" },
};

const SPEECH_LANGUAGES: { code: string; label: string }[] = [
  { code: "en-US", label: "English (US)" },
  { code: "en-GB", label: "English (UK)" },
  { code: "en-IN", label: "English (India)" },
  { code: "hi-IN", label: "हिन्दी (Hindi)" },
  { code: "ta-IN", label: "தமிழ் (Tamil)" },
  { code: "te-IN", label: "తెలుగు (Telugu)" },
  { code: "kn-IN", label: "ಕನ್ನಡ (Kannada)" },
  { code: "ml-IN", label: "മലയാളം (Malayalam)" },
  { code: "mr-IN", label: "मराठी (Marathi)" },
  { code: "bn-IN", label: "বাংলা (Bengali)" },
  { code: "gu-IN", label: "ગુજરાતી (Gujarati)" },
  { code: "pa-IN", label: "ਪੰਜਾਬੀ (Punjabi)" },
  { code: "ur-IN", label: "اردو (Urdu)" },
  { code: "es-ES", label: "Español (Spain)" },
  { code: "es-MX", label: "Español (México)" },
  { code: "fr-FR", label: "Français" },
  { code: "de-DE", label: "Deutsch" },
  { code: "it-IT", label: "Italiano" },
  { code: "pt-BR", label: "Português (Brasil)" },
  { code: "ru-RU", label: "Русский" },
  { code: "ar-SA", label: "العربية" },
  { code: "zh-CN", label: "中文 (简体)" },
  { code: "ja-JP", label: "日本語" },
  { code: "ko-KR", label: "한국어" },
];

const LANG_STORAGE_KEY = "medisphere_speech_lang";

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading,
  currentMode,
  onModeChange,
}) => {
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<{ type: string; name: string }[]>([]);
  const [speechLang, setSpeechLang] = useState<string>(() => {
    if (typeof window === "undefined") return "en-US";
    return localStorage.getItem(LANG_STORAGE_KEY) || "en-US";
  });
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const handleSend = (overrideText?: string) => {
    const text = (overrideText ?? input).trim();
    if (!text && attachments.length === 0) return;
    onSendMessage(text, attachments.length > 0 ? attachments : undefined);
    setInput("");
    setAttachments([]);
  };

  const { isListening, isSupported: speechSupported, start: startListening, stop: stopListening } =
    useSpeechRecognition({
      lang: speechLang,
      onPartial: (partial) => setInput(partial),
      onFinal: (finalText) => {
        setInput("");
        handleSend(finalText);
      },
    });

  const handleLangChange = (code: string) => {
    setSpeechLang(code);
    try {
      localStorage.setItem(LANG_STORAGE_KEY, code);
    } catch {
      // ignore
    }
    if (isListening) stopListening();
  };

  const handleMicClick = () => {
    if (!speechSupported) {
      toast.error("Voice input isn't supported in this browser. Try Chrome or Safari.");
      return;
    }
    if (isListening) {
      stopListening();
    } else {
      stopSpeaking(); // stop any ongoing TTS before listening
      startListening();
    }
  };

  // Stop TTS/mic when component unmounts
  useEffect(() => {
    return () => {
      stopListening();
      stopSpeaking();
    };
  }, [stopListening]);

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, type: string) => {
    const files = e.target.files;
    if (files) {
      const newAttachments = Array.from(files).map(f => ({
        type,
        name: f.name,
      }));
      setAttachments(prev => [...prev, ...newAttachments]);
    }
    e.target.value = "";
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="border-t border-border bg-card p-4">
      {/* Mode indicator */}
      {currentMode !== "default" && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 mb-2 text-sm"
        >
          <span className={cn("flex items-center gap-1", modeConfig[currentMode].color)}>
            {modeConfig[currentMode].icon}
            {modeConfig[currentMode].label} Mode
          </span>
          <Button
            variant="ghost"
            size="sm"
            className="h-5 px-1"
            onClick={() => onModeChange("default")}
          >
            <X className="w-3 h-3" />
          </Button>
        </motion.div>
      )}

      {/* Attachments preview */}
      <AnimatePresence>
        {attachments.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="flex flex-wrap gap-2 mb-3"
          >
            {attachments.map((att, idx) => (
              <div
                key={idx}
                className="flex items-center gap-1.5 px-2 py-1 bg-muted rounded-md text-sm"
              >
                <Paperclip className="w-3 h-3" />
                <span className="truncate max-w-[150px]">{att.name}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-4 w-4 p-0"
                  onClick={() => removeAttachment(idx)}
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input area */}
      <div className="flex items-end gap-2">
        {/* Action buttons */}
        <div className="flex gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9"
                onClick={() => imageInputRef.current?.click()}
              >
                <Image className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Add Image</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9"
                onClick={() => fileInputRef.current?.click()}
              >
                <Paperclip className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Attach File</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <Camera className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Take Photo</TooltipContent>
          </Tooltip>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onClick={() => onModeChange("thinking")}>
                <Brain className="w-4 h-4 mr-2" />
                Thinking Mode
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onModeChange("deep_search")}>
                <Search className="w-4 h-4 mr-2" />
                Deep Search
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => onModeChange("study")}>
                <GraduationCap className="w-4 h-4 mr-2" />
                Study & Learn
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onModeChange("quiz")}>
                <FileQuestion className="w-4 h-4 mr-2" />
                Quiz Mode
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Globe className="w-4 h-4 mr-2" />
                Web Search
              </DropdownMenuItem>
              <DropdownMenuItem>
                <ShoppingCart className="w-4 h-4 mr-2" />
                Shopping Research
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Text input */}
        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isListening ? "Listening… speak now" : "Ask MediSphere anything about health..."}
            className="min-h-[44px] max-h-[200px] resize-none pr-12 py-3"
            rows={1}
          />
        </div>

        {/* Send / Voice button */}
        <div className="flex gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <div>
                <Select value={speechLang} onValueChange={handleLangChange}>
                  <SelectTrigger
                    className="h-9 w-[60px] px-2 gap-1 border-none bg-transparent hover:bg-accent/50 focus:ring-0 [&>span]:hidden"
                    aria-label="Voice input language"
                  >
                    <Languages className="w-4 h-4" />
                  </SelectTrigger>
                  <SelectContent align="end" className="max-h-[300px]">
                    {SPEECH_LANGUAGES.map((l) => (
                      <SelectItem key={l.code} value={l.code}>
                        {l.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              Voice language: {SPEECH_LANGUAGES.find((l) => l.code === speechLang)?.label}
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant={isListening ? "default" : "ghost"}
                size="icon"
                className={cn(
                  "h-9 w-9 transition-all",
                  isListening && "bg-destructive hover:bg-destructive/90 text-destructive-foreground animate-pulse-glow"
                )}
                onClick={handleMicClick}
                aria-label={isListening ? "Stop listening" : "Start voice input"}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>
            </TooltipTrigger>
            <TooltipContent>{isListening ? "Tap to stop" : "Voice input"}</TooltipContent>
          </Tooltip>

          <Button
            size="icon"
            className="h-9 w-9 bg-accent hover:bg-accent/90"
            onClick={() => handleSend()}
            disabled={isLoading || (!input.trim() && attachments.length === 0)}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        multiple
        onChange={(e) => handleFileSelect(e, "file")}
      />
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        multiple
        onChange={(e) => handleFileSelect(e, "image")}
      />
    </div>
  );
};
