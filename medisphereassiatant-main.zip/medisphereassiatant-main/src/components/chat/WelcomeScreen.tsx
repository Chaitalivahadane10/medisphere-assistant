import React from "react";
import { motion } from "framer-motion";
import { 
  Heart, 
  Pill, 
  Stethoscope, 
  Brain,
  GraduationCap,
  ShieldCheck,
} from "lucide-react";

const suggestions = [
  { icon: <Stethoscope className="w-5 h-5" />, text: "Explain common symptoms of hypertension" },
  { icon: <Pill className="w-5 h-5" />, text: "What are the side effects of ibuprofen?" },
  { icon: <Heart className="w-5 h-5" />, text: "How to maintain a healthy heart?" },
  { icon: <Brain className="w-5 h-5" />, text: "Tips for better mental health" },
];

interface WelcomeScreenProps {
  onSuggestionClick: (text: string) => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onSuggestionClick }) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 max-w-2xl mx-auto">
      {/* Logo */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.4 }}
        className="mb-6"
      >
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-glow">
          <ShieldCheck className="w-10 h-10 text-white" />
        </div>
      </motion.div>

      {/* Title */}
      <motion.h1
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="text-3xl font-bold text-foreground mb-2 text-center"
      >
        Welcome to MediSphere
      </motion.h1>

      <motion.p
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="text-muted-foreground text-center mb-8 max-w-md"
      >
        Your complete healthcare & pharmacy knowledge assistant. Ask me anything about medicine, wellness, or pharmacy education.
      </motion.p>

      {/* Capabilities */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="flex flex-wrap justify-center gap-3 mb-8"
      >
        <div className="flex items-center gap-2 px-3 py-1.5 bg-secondary rounded-full text-sm">
          <GraduationCap className="w-4 h-4 text-accent" />
          <span>Medical Education</span>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-secondary rounded-full text-sm">
          <Pill className="w-4 h-4 text-accent" />
          <span>Pharmacy Knowledge</span>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-secondary rounded-full text-sm">
          <Heart className="w-4 h-4 text-accent" />
          <span>Wellness Tips</span>
        </div>
      </motion.div>

      {/* Suggestions */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="grid gap-3 w-full max-w-lg"
      >
        <p className="text-sm text-muted-foreground text-center mb-1">
          Try asking about:
        </p>
        {suggestions.map((suggestion, index) => (
          <motion.button
            key={index}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5 + index * 0.1 }}
            onClick={() => onSuggestionClick(suggestion.text)}
            className="flex items-center gap-3 p-4 bg-card border border-border rounded-xl hover:border-accent hover:shadow-md transition-all text-left group"
          >
            <div className="p-2 bg-accent/10 rounded-lg text-accent group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
              {suggestion.icon}
            </div>
            <span className="text-sm text-foreground">{suggestion.text}</span>
          </motion.button>
        ))}
      </motion.div>
    </div>
  );
};
