import { useEffect, useRef, useState, useCallback } from "react";

// Browser SpeechRecognition (Chrome, Edge, Safari iOS 14.5+, Android Chrome)
type SpeechRecognitionLike = any;

declare global {
  interface Window {
    SpeechRecognition?: any;
    webkitSpeechRecognition?: any;
  }
}

interface UseSpeechRecognitionOptions {
  /** Called once with the final transcript after the user stops talking. */
  onFinal: (transcript: string) => void;
  /** Live partial transcript (optional). */
  onPartial?: (transcript: string) => void;
  /** BCP-47 language code, e.g. "en-US". */
  lang?: string;
}

export function useSpeechRecognition({
  onFinal,
  onPartial,
  lang = "en-US",
}: UseSpeechRecognitionOptions) {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const finalTranscriptRef = useRef("");

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    setIsSupported(!!SR);
  }, []);

  const start = useCallback(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;

    // Reset
    finalTranscriptRef.current = "";
    const recognition = new SR();
    recognition.lang = lang;
    recognition.continuous = false; // auto-stops on silence
    recognition.interimResults = true;

    recognition.onresult = (event: any) => {
      let interim = "";
      let finalText = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += transcript;
        else interim += transcript;
      }
      if (finalText) finalTranscriptRef.current += finalText;
      if (onPartial) onPartial(finalTranscriptRef.current + interim);
    };

    recognition.onerror = () => {
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
      const final = finalTranscriptRef.current.trim();
      if (final) onFinal(final);
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
      setIsListening(true);
    } catch {
      // already started
    }
  }, [lang, onFinal, onPartial]);

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
  }, []);

  return { isListening, isSupported, start, stop };
}

// ---------- Text to Speech ----------

export function speak(text: string, lang = "en-US") {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  // Strip markdown for cleaner speech
  const clean = text
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/[*_`#>~|-]/g, " ")
    .replace(/\[(.*?)\]\(.*?\)/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(clean);
  utter.lang = lang;
  utter.rate = 1;
  utter.pitch = 1;
  window.speechSynthesis.speak(utter);
}

export function stopSpeaking() {
  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
}

export function isTtsSupported() {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}
