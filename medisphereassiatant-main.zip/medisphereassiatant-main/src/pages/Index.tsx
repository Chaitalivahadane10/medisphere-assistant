import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { Menu, X, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuth } from "@/contexts/AuthContext";
import { useChat } from "@/hooks/useChat";
import { useConversations } from "@/hooks/useConversations";
import { ChatSidebar } from "@/components/layout/ChatSidebar";
import { ChatMessage } from "@/components/chat/ChatMessage";
import { ChatInput } from "@/components/chat/ChatInput";
import { TypingIndicator } from "@/components/chat/TypingIndicator";
import { WelcomeScreen } from "@/components/chat/WelcomeScreen";
import { cn } from "@/lib/utils";
import { speak, stopSpeaking } from "@/hooks/useSpeech";

const Index: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading, signOut } = useAuth();
  const { 
    messages, 
    isLoading, 
    sendMessage, 
    clearMessages,
    loadMessages,
    currentMode,
    setCurrentMode,
  } = useChat();
  const {
    conversations,
    currentConversationId,
    setCurrentConversationId,
    createConversation,
    deleteConversation,
    updateConversationTitle,
    clearAllConversations,
  } = useConversations();

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [voiceReplyEnabled, setVoiceReplyEnabled] = useState(true);
  const lastSpokenIdRef = useRef<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-speak the latest assistant reply when streaming finishes
  useEffect(() => {
    if (!voiceReplyEnabled || isLoading) return;
    const last = messages[messages.length - 1];
    if (last && last.role === "assistant" && last.content.trim() && lastSpokenIdRef.current !== last.id) {
      lastSpokenIdRef.current = last.id;
      speak(last.content);
    }
  }, [messages, isLoading, voiceReplyEnabled]);

  // Stop any speech on unmount
  useEffect(() => () => stopSpeaking(), []);

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleNewConversation = async () => {
    clearMessages();
    setCurrentConversationId(null);
  };

  const handleSelectConversation = async (id: string) => {
    setCurrentConversationId(id);
    await loadMessages(id);
  };

  const handleSendMessage = async (content: string, attachments?: { type: string; name: string }[]) => {
    let convoId = currentConversationId;

    // Create a conversation if none exists
    if (!convoId) {
      const newConvo = await createConversation(content.slice(0, 50));
      if (!newConvo) return;
      convoId = newConvo.id;
      setCurrentConversationId(convoId);
    } else {
      // Update the title if it's still the default
      const currentConvo = conversations.find(c => c.id === convoId);
      if (currentConvo?.title === "New Conversation") {
        updateConversationTitle(convoId, content.slice(0, 50));
      }
    }

    sendMessage(content, convoId, attachments);
  };

  const handleClearCurrent = async () => {
    if (currentConversationId) {
      await deleteConversation(currentConversationId);
    }
    clearMessages();
    setCurrentConversationId(null);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/auth");
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-accent border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground">Loading MediSphere...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="h-screen flex overflow-hidden bg-background">
      {/* Mobile sidebar toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 lg:hidden"
        onClick={() => setSidebarOpen(!sidebarOpen)}
      >
        {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </Button>

      {/* Voice reply toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 right-4 z-50"
        onClick={() => {
          if (voiceReplyEnabled) stopSpeaking();
          setVoiceReplyEnabled(v => !v);
        }}
        aria-label={voiceReplyEnabled ? "Mute voice replies" : "Enable voice replies"}
        title={voiceReplyEnabled ? "Voice replies on — tap to mute" : "Voice replies muted — tap to enable"}
      >
        {voiceReplyEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5 text-muted-foreground" />}
      </Button>

      {/* Sidebar */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-40 lg:relative lg:flex transition-transform duration-300",
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <ChatSidebar
          conversations={conversations}
          currentConversationId={currentConversationId}
          onSelectConversation={handleSelectConversation}
          onNewConversation={handleNewConversation}
          onDeleteConversation={deleteConversation}
          onClearCurrent={handleClearCurrent}
          onClearAll={async () => { await clearAllConversations(); clearMessages(); }}
          onSignOut={handleSignOut}
          userEmail={user.email}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
      </div>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Chat messages */}
        <ScrollArea 
          ref={scrollRef}
          className="flex-1 custom-scrollbar"
        >
          {messages.length === 0 ? (
            <WelcomeScreen onSuggestionClick={handleSendMessage} />
          ) : (
            <div className="max-w-4xl mx-auto pb-4">
              {messages.map((message) => (
                <ChatMessage key={message.id} message={message} />
              ))}
              <AnimatePresence>
                {isLoading && messages[messages.length - 1]?.role === "user" && (
                  <TypingIndicator />
                )}
              </AnimatePresence>
            </div>
          )}
        </ScrollArea>

        {/* Input area */}
        <div className="max-w-4xl mx-auto w-full">
          <ChatInput
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            currentMode={currentMode}
            onModeChange={setCurrentMode}
          />
        </div>
      </div>
    </div>
  );
};

export default Index;
